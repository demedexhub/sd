/* const sound_group_collection = [
    
]

const bird_park =     {
    name: 'Birds',
    groupID: 'bird',
    number: undefined,
    color: 'yellow',
    focusAudioShot: 'assets/audio/bird/fx.ogg',
    url: 'assets/audio/bird/',
    volumeRangeValue: 0, volumeRangeValueMinimo: -25, volumeRangeValueMassimo: 1, volumeRangeValueStep: 2, volumeRangeValueOrientation: 'horizontal', focus: true,  mainNodeCreated: false,
    
    sounds: [
        {   moduleID: 'bird-background',
            audioFiles: [],
            number: 0,
            amount: 1 + 1,

            loop: true,
            url: 'background/bird-background',
            type: 'background',
            fadeIn: 5,
            fadeOut: 5,

            minimumVolumeRange: -18,
            volumeRangeValue: 0, volumeRangeValueMinimo: -25, volumeRangeValueMassimo: 1, volumeRangeValueStep: 2, playing: true
        },


        {   moduleID: 'bird-scatter1',
            audioFiles: [],
            number: 1,
            amount: 11 + 1,

            loop: false,
            url: 'scatter01/bird',
            type: 'scatter',

            minTime: 2,
            maxTime: 5,
            minVolume: -7,
            maxVolume: 1,

            minimumVolumeRange: -18,
            volumeRangeValue: 0, volumeRangeValueMinimo: -25, volumeRangeValueMassimo: 1, volumeRangeValueStep: 2, playing: true
        },

        
    ]
}

const car_park =     {
    name: 'Cars',
    groupID: 'car',
    number: undefined,
    color: 'green',
    focusAudioShot: 'assets/audio/car/fx.ogg',
    url: 'assets/audio/car/',
    volumeRangeValue: 0, volumeRangeValueMinimo: -25, volumeRangeValueMassimo: 1, volumeRangeValueStep: 2, volumeRangeValueOrientation: 'horizontal', focus: true,  mainNodeCreated: false,
    
    sounds: [
        {   moduleID: 'car-background',
            audioFiles: [],
            number: 0,
            amount: 1 + 1,

            loop: true,
            url: 'background/car-background',
            type: 'background',
            fadeIn: 5,
            fadeOut: 5,

            minimumVolumeRange: -18,
            volumeRangeValue: 0, volumeRangeValueMinimo: -25, volumeRangeValueMassimo: 1, volumeRangeValueStep: 2, playing: true
        },


        {   moduleID: 'car-scatter1',
            audioFiles: [],
            number: 1,
            amount: 11 + 1,

            loop: false,
            url: 'scatter01/car',
            type: 'scatter',

            minTime: 2,
            maxTime: 5,
            minVolume: -7,
            maxVolume: 1,

            minimumVolumeRange: -18,
            volumeRangeValue: 0, volumeRangeValueMinimo: -25, volumeRangeValueMassimo: 1, volumeRangeValueStep: 2, playing: true
        },

        
    ]
} */